# Parameter registry (DRAFT)

> **Status:** Revised from [scenarios.md](scenarios.md). Still draft — tune defaults before release.  
> Legacy names from the original inline-MCU notes appear **only** in the **AKA** column below.

## MCU behavior & timing

| Parameter | AKA | Default | Units | Defines |
|-----------|-----|---------|-------|---------|
| `wakeHalfPressHoldTime` | X | 10 | s | On brief wide-PIR HP stab, assert camera HP for this duration if no FP starts an activity (SC-04). Refreshed when each sequence starts (R15). Not a cap on total activity length — bounded by `SequenceCount`, `FrameCount`, `StartFrameSpacingMin`, `PostShutterHalfPressHoldTimeExtension`, and sequence logic. |
| `wakeHoldRefreshPolicy` | — | `extend` | enum | Repeated HP during wake: `extend`, `restart`, `ignoreWhileActive` (SC-04b). |
| `minHalfPressBeforeShutter` | T | 0.5 | s | **Gate before each shutter** — not extra spacing between frames. At each scheduled fire time, HP must have been on ≥ this long (assert HP and wait only if lead is short). Does **not** add on top of `StartFrameSpacingMin` when HP stays latched through the burst. See [behavior-spec § Burst frame scheduling](behavior-spec.md#burst-frame-scheduling-within-one-sequence). |
| `fullPressIgnoreGap` | — | 3.1 | s | After **sequence start**, ignore FP **inputs** for this duration (R10). PIR **Gap** = minimum — see [pir-sensor-settings.md](pir-sensor-settings.md). **Default estimate** (recalc when burst params change): `(FrameCount - 1) × StartFrameSpacingMin + shutterPulseDuration` — e.g. 3×1.0 + 0.1 = 3.1 s with registry defaults; set longer if retriggers persist after burst or gates stretch spacing. |
| `FrameCount` | N | 4 | frames | Shutter activations per accepted trigger (one sequence). |
| `SequenceCount` | — | 3 | sequences | Max full-press sequences per activity (limits by count, not wall-clock). |
| `StartFrameSpacingMin` | Y | 1.0 | s | **Minimum** time from **start** of one FP OUT pulse to **start** of the next (R6). Does **not** include `shutterPulseDuration`. Actual spacing may exceed this if `minHalfPressBeforeShutter` (or HP release) delays the next start — e.g. when `PostShutterHalfPressHoldTimeExtension` is low/zero and T > Y between sequences. |
| `PostShutterHalfPressHoldTimeExtension` | Z | 2.0 | s | After the last shutter in a sequence, **extend** camera HP hold by this duration (R11). HP may remain latched for another sequence; accepting the next sequence may shorten the remainder (R15). |
| `shutterPulseDuration` | — | 100 | ms | How long each FP output pulse is held (camera single-shot; MCU generates pulses). |
| `halfPressInputDebounce` | — | 20–50 | ms | Reject short glitches on HP in (SC-13). |
| `fullPressInputDebounce` | — | 10–30 | ms | Reject short glitches on FP in (SC-13, SC-14). |

Half press is not dropped because of trigger activations during a burst (original §4b) → `halfPressDuringBurstPolicy = independent`.

### Sequence vs activity

| Concept | Parameter | Example |
|---------|-----------|---------|
| Frames per trigger | `FrameCount` | 4 frames per sequence |
| How many trigger series per activity | `SequenceCount` | 3 sequences (up to 12 frames if all bursts complete) |
| Wake hold extended by shooting | `wakeHalfPressHoldTime` + R15 | Sequences keep camera awake |

## Scenario traceability

| Parameter | Primary scenarios |
|-----------|-------------------|
| `wakeHalfPressHoldTime` | SC-04, SC-12; extended per sequence (R15) |
| `wakeHoldRefreshPolicy` | SC-04b, SC-07b, SC-12 |
| `minHalfPressBeforeShutter` | SC-01, SC-05, SC-06, SC-08 |
| `fullPressIgnoreGap` | SC-02, SC-03 |
| `FrameCount` | SC-01, SC-02, SC-03 (frames per sequence) |
| `SequenceCount` | SC-05, SC-09 |
| `StartFrameSpacingMin` | SC-01, SC-11 |
| `activityHalfPressHoldPolicy` | SC-03, SC-07 |
| `fpAfterSequenceCountPolicy` | SC-09 |
| `halfPressDuringBurstPolicy` | SC-07 |
| `fullPressWithoutPriorHpPolicy` | SC-06, SC-08 |
| `PostShutterHalfPressHoldTimeExtension` | SC-01, SC-05b (per sequence) |

## Policies (enums)

| Parameter | Default | Values | Defines |
|-----------|---------|--------|---------|
| `halfPressDuringBurstPolicy` | `independent` | `independent` | HP input during burst (SC-07) |
| `fullPressWithoutPriorHpPolicy` | `assertHpThenWait` | `assertHpThenWait` | Cold FP (SC-06) |
| `activityHalfPressHoldPolicy` | `holdUntilActivityEnd` | `holdUntilActivityEnd` | Camera HP across sequences until activity ends (R13) |
| `fpAfterSequenceCountPolicy` | `ignoreUntilActivityEnd` | `ignoreUntilActivityEnd`, `endActivityImmediately` | FP after `SequenceCount` (SC-09) |
| `wakeHoldRefreshPolicy` | `extend` | `extend`, `restart`, `ignoreWhileActive` | SC-04b |

PIR v4 menu values (wide/far modes, gap, NUM, C Vars, etc.) live in **[pir-sensor-settings.md](pir-sensor-settings.md)** — not in this MCU registry.

## Hardware / platform

| Parameter | Default | Defines |
|-----------|---------|---------|
| `inputActivePolarity` | `active-low` | HP/FP active state |
| `outputDriveMode` | `open-drain` / opto | Switch closure |
| `powerSaveIdleMode` | enabled | SC-15 |
| `statusLedMode` | optional | LED behavior |

## Removed parameters

| Name | Reason |
|------|--------|
| `focusAcquisitionMs` | Redundant with `minHalfPressBeforeShutter` when HP is held through burst (normal). Removed to avoid confusion with `StartFrameSpacingMin`. |
| `maxWakeHalfPressHoldTime` | No global time cap; limits are `SequenceCount` and per-sequence timing |
| `maxFrames` | Replaced by `SequenceCount` (was `maxSequences`) |
| `burstFrameCount` | Renamed `FrameCount` |
| `maxSequences` | Renamed `SequenceCount` |
| `interFrameDelay` | Renamed `StartFrameSpacingMin` |
| `fpAfterMaxSequencesPolicy` | Renamed `fpAfterSequenceCountPolicy` |
| `postBurstHalfPressHoldTime` | Renamed `PostShutterHalfPressHoldTimeExtension` |
| `minStrobeRecycleTime` | Not an MCU parameter |
| `cameraDriveMode` | Set on camera body |
| `triggerDuringBurstPolicy` | Replaced by `fullPressIgnoreGap` |

## Behavior matrix (compact)

| Condition | Behavior |
|-----------|----------|
| HP wake | Assert HP; start/extend `wakeHalfPressHoldTime` |
| No FP before wake hold expires | Release HP (SC-04) |
| Activity active | HP per `activityHalfPressHoldPolicy` (R13) |
| FP accepted → new sequence | Schedule `FrameCount` if `< SequenceCount` (R10b) |
| FP during `fullPressIgnoreGap` | Ignored (R10) |
| FP after sequence complete | May start next sequence if `< SequenceCount` (R10b, R12) |
| `SequenceCount` reached | `fpAfterSequenceCountPolicy` |
| Sequence complete | `PostShutterHalfPressHoldTimeExtension` (R11); HP may stay latched |
| FP after sequence complete | Next sequence same activity (R12, R15) if under cap |
| HP during burst | Ignored for scheduling (R14) |

## Defaults workshop

| Parameter | SC-01 | SC-09 | SC-05 | Default |
|-----------|-------|-------|-------|---------|
| `FrameCount` | 4 | — | 4 | 4 frames / sequence |
| `SequenceCount` | 1 | 3 cap | 2+ | 3 / activity |
| `fullPressIgnoreGap` | — | — | — | 3.1 s ((N-1)×Y + pulse estimate) |

## Open decisions

- [ ] Exact R15 mechanism: extend `wakeHalfPressHoldTime` on FP accept vs separate timer
- [ ] `SequenceCount` default (3)
- [ ] Confirm `StartFrameSpacingMin` measured rising-edge to rising-edge on FP OUT starts (implementation detail)

When revising, update [scenarios.md](scenarios.md) and [diagrams/](diagrams/) together.
