# Timing sequence examples

Waveform-style views cross-linked to [scenarios.md](../scenarios.md). Use [parameters.md](../parameters.md) for configured values.

**Read this first:** [Nominal path (defaults)](#nominal-path-defaults) — HP OUT latched for the whole activity; exceptions are labeled below.

| Section | Scenario |
|---------|----------|
| **Nominal** | [SC-01](#nominal-path-defaults) — default happy path |
| A | [SC-04](../scenarios.md#sc-04--wake-timeout-no-fp) Wake timeout *(exception)* |
| B | [SC-06](../scenarios.md#sc-06--cold-fp-no-prior-wake) Cold FP *(exception)* |
| C | [SC-01](../scenarios.md#sc-01--normal-wake-then-shoot) Same as nominal (detail) |
| D | [SC-02](../scenarios.md#sc-02--fp-during-sequence-ignored) / [SC-03](../scenarios.md#sc-03--fp-flood-during-burst-ignored) FP ignored (R10) |
| E | [Burst scheduling](../behavior-spec.md#burst-frame-scheduling-within-one-sequence) StartFrameSpacingMin vs T |
| F | [SC-05](../scenarios.md#sc-05--back-to-back-sequence) Back-to-back sequence |
| G | [SC-07](../scenarios.md#sc-07--hp-during-active-burst) HP during burst *(exception input)* |

## Nominal path (defaults)

**This is the intended field behavior** with default parameters and `activityHalfPressHoldPolicy = holdUntilActivityEnd` (R7, R13).

| Parameter | Default | Role in this diagram |
|-----------|---------|----------------------|
| `minHalfPressBeforeShutter` (T) | 0.5 s | Gates frame 1 only if HP lead too short |
| `StartFrameSpacingMin` (Y) | 1.0 s | Min start-to-start between frames 2…N |
| `FrameCount` (N) | 4 | Shutter pulses per sequence |
| `PostShutterHalfPressHoldTimeExtension` (Z) | 2.0 s | HP hold after last frame |
| `shutterPulseDuration` | 100 ms | FP OUT pulse width |
| `wakeHalfPressHoldTime` (X) | 10 s | Wake-only timeout (extended by R15 during shoot) |

**SC-01 timeline:** HP wake t=0, FP accepted t=1.0 s (HP lead already ≥ T). **Camera HP OUT goes ON once** and stays latched through burst + Z. **No** extra T-wait between frames 2…N.

```mermaid
sequenceDiagram
    participant HPi as HP in
    participant FPi as FP in
    participant MCU
    participant HPo as HP out
    participant FPo as FP out

    HPi->>MCU: wake t=0
    MCU->>HPo: ON once latched
    Note over HPo: HP OUT high entire activity R7 R13
    FPi->>MCU: FP accepted t=1.0s starts sequence
    Note over MCU: R10 ignore all FP until burst done
    MCU->>FPo: frame 1 t=1.0s
    MCU->>FPo: frame 2 t=2.0s
    MCU->>FPo: frame 3 t=3.0s
    MCU->>FPo: frame 4 t=4.0s
    Note over MCU,HPo: PostShutterHalfPressHoldTimeExtension Z=2s HP still ON
    MCU->>HPo: OFF t≈6s activity end
```

**ASCII (camera outputs)**

```
HP out: ████████████████████████████████████  ON from t=0 until after Z
FP out: ········┌┐───┌┐───┌┐───┌┐
              1.0  2.0  3.0  4.0   (+ Z=2.0 s, then HP OFF)
FP in:  ········█  (retriggers during burst ignored, R10)
```

Exception paths: [A wake timeout](#a--sc-04-wake-only-then-timeout), [B cold FP](#b--sc-06-fp-without-prior-wake-cold-start), [G HP input during burst](#g--sc-07-hp-during-burst-no-effect-on-schedule), mid-burst HP release in [behavior-spec](../behavior-spec.md#exception-path-hp-released-mid-burst).

---

## A — SC-04: Wake only, then timeout

*Exception — not the nominal shoot path.*

```mermaid
sequenceDiagram
    participant HPi as HP input (wide PIR)
    participant MCU
    participant HPo as HP out (camera)
    participant FPi as FP input

    HPi->>MCU: glitchy pulses
    MCU->>HPo: ON (latched)
    Note over MCU,HPo: wakeHalfPressHoldTime = 10s
    Note over FPi: no FP
    MCU->>HPo: OFF
```

## B — SC-06: FP without prior wake (cold start)

*Exception — FP before any HP wake.*

```mermaid
sequenceDiagram
    participant FPi as FP input
    participant MCU
    participant HPo as HP out
    participant FPo as FP out

    FPi->>MCU: FP assert
    MCU->>HPo: ON immediately
    Note over MCU: wait minHalfPressBeforeShutter T
    MCU->>FPo: frame 1
    Note over MCU: frames 2..N at StartFrameSpacingMin HP stays on
```

## C — SC-01: Wake then FP at 1 s

Same as [Nominal path](#nominal-path-defaults). Canonical reference for acceptance tests.

## D — SC-02 / SC-03: FP ignored during sequence (R10)

*Overlay on nominal burst — PIR Gap minimum.*

MCU ignores **all** FP **inputs** from sequence start until the burst **schedule** completes (R10). `fullPressIgnoreGap` is a timing budget, not a per-retrigger window after each pulse.

```mermaid
sequenceDiagram
    participant FPi as FP_in
    participant MCU
    participant HPo as HP_out
    participant FPo as FP_out

    Note over HPo: HP OUT latched whole sequence
    FPi->>MCU: FP1 starts sequence
    Note over MCU: R10 discard FP until burst done
    FPi->>MCU: retriggers ignored
    MCU->>FPo: FrameCount scheduled pulses only
```

SC-03: many FP inputs during burst → still only `FrameCount` frames — see [scenarios.md](../scenarios.md#sc-03--fp-flood-during-burst-ignored).

## E — Burst schedule: StartFrameSpacingMin (min) vs minHalfPressBeforeShutter

*Nominal spacing when HP never drops — teaching example from behavior-spec (sequence start at HP assert).*

| Event | Time |
|-------|------|
| HP asserted | 0.0 s |
| Frame 1 OUT | 0.5 s (after T) |
| Frame 2 OUT | 1.5 s |
| Frame 3 OUT | 2.5 s |
| Frame 4 OUT | 3.5 s |

Frames 2…N use **Y only** — no second T-wait. See [behavior-spec](../behavior-spec.md#burst-frame-scheduling-within-one-sequence).

```mermaid
sequenceDiagram
    participant HPo as HP out
    participant FPo as FP out

    Note over HPo: ON latched entire burst R7
    Note over FPo: frame 1 at 0.5s after T
    Note over FPo: frame 2 at 1.5s +Y from prev start
    Note over FPo: frame 3 at 2.5s
    Note over FPo: frame 4 at 3.5s
```

## F — SC-05: Back-to-back sequence

*Nominal multi-sequence — HP OUT stays latched across both sequences (R13).*

```mermaid
sequenceDiagram
    participant FPi as FP in
    participant MCU
    participant HPo as HP out
    participant FPo as FP out

    Note over HPo: HP ON entire activity no drop between sequences
    MCU->>FPo: sequence 1 frames
    Note over MCU,HPo: PostShutter extension may be shortened
    FPi->>MCU: FP2 accepted sequence 2 R12
    MCU->>FPo: sequence 2 frames
    Note over MCU,HPo: Z then release when activity ends
```

## G — SC-07: HP during burst (no effect on schedule)

*Exception input — wide PIR glitches during burst; schedule unchanged (R14).*

```
HP in:  ~ ~ ~     (ignored during burst)
HP out: ████████████████████  (latched — nominal)
FP in:  ·······█~~ignored~~█··  (R10 whole sequence, PIR Gap min)
FP out: ·······┌┐──┌┐──┌┐──┌┐
```

HP **input** does not reset `remainingFrames` or add frames (**R14**). Camera HP **output** stays latched (**R7**).
