# Operational scenarios

Primary specification artifact for timing behavior. Each scenario has a stable ID for acceptance tests, customer explanations, and parameter tuning.

**Related docs:** [behavior-spec.md](behavior-spec.md) (rules R1–R15) · [parameters.md](parameters.md) · [diagrams/](diagrams/)

## Traceability

| ID | Title | Key parameters | Policies / rules |
|----|-------|----------------|------------------|
| SC-01 | Normal wake then shoot | `wakeHalfPressHoldTime`, `FrameCount`, `StartFrameSpacingMin`, `PostShutterHalfPressHoldTimeExtension` | R1, R4–R6, R11, R13 |
| SC-02 | FP during sequence ignored | `fullPressIgnoreGap`, `FrameCount`, `StartFrameSpacingMin` | R9, R10, R10b, R13 |
| SC-03 | FP flood during burst ignored | `fullPressIgnoreGap`, `FrameCount`, `StartFrameSpacingMin` | R10, R10b, R13 |
| SC-04 | Wake timeout | `wakeHalfPressHoldTime`, `wakeHoldRefreshPolicy` | R2 |
| SC-04b | Repeated wake pulses | `wakeHoldRefreshPolicy` | R1 |
| SC-05 | Back-to-back sequence | `SequenceCount`, `PostShutterHalfPressHoldTimeExtension` | R4, R12, R15 |
| SC-05b | FP during post-shutter HP hold extension | `PostShutterHalfPressHoldTimeExtension` | R11, R12, R15 |
| SC-06 | Cold FP (no prior wake) | `minHalfPressBeforeShutter`, `fullPressWithoutPriorHpPolicy` | R3, R4 |
| SC-07 | HP during burst | `halfPressDuringBurstPolicy` | R13, R14 |
| SC-07b | HP during post-burst hold | `wakeHoldRefreshPolicy` | R11, R15 |
| SC-08 | FP before HP | `minHalfPressBeforeShutter`, `fullPressWithoutPriorHpPolicy` | R3, R4 |
| SC-09 | FP at SequenceCount cap | `SequenceCount`, `fpAfterSequenceCountPolicy` | R10b, R13 |
| SC-10 | Recovery after cap | `fpAfterSequenceCountPolicy` | R12 |
| SC-11 | StartFrameSpacingMin vs T (Y) | `StartFrameSpacingMin`, `minHalfPressBeforeShutter` | R4, R6, R7 |
| SC-12 | HP only (PIR Gap minimum) | `wakeHalfPressHoldTime` | R1, R2, R10, R13 |
| SC-13 | Input debounce glitches | `halfPressInputDebounce`, `fullPressInputDebounce` | R1 |
| SC-14 | Held vs pulsed FP input | `fullPressInputDebounce` | R5 |
| SC-15 | Power-save wake latency | `powerSaveIdleMode` | — |
| SC-16 | Mis-wired HP/FP | — | undefined |

### Illustrative defaults (examples in this doc)

| Parameter | Example value |
|-----------|---------------|
| `wakeHalfPressHoldTime` | 10 s |
| `minHalfPressBeforeShutter` | 0.5 s |
| `FrameCount` | 4 |
| `StartFrameSpacingMin` | 1.0 s |
| `PostShutterHalfPressHoldTimeExtension` | 2.0 s |
| `SequenceCount` | 3 per activity |
| `fullPressIgnoreGap` | 3.1 s (estimate (N-1)×Y + pulse) |
| PIR Gap | minimum (0.5 s) — see [pir-sensor-settings.md](pir-sensor-settings.md) |

---

## Scenario template

Each defined scenario uses:

- **Intent** — real-world situation
- **Preconditions** — MCU state before inputs
- **Input timeline** — HP/FP from trigger system
- **Expected behavior** — camera outputs and counters
- **Status** — `defined` | `needs decision` | `proposed`

---

## SC-01 — Normal wake then shoot

**Status:** defined

**Intent:** Typical trap event: wide motion wakes the camera, subject enters narrow FOV about a second later, full burst fires, system returns to sleep.

**Preconditions:** Idle. `sequencesStartedThisActivity = 0`.

**Input timeline**

| Time | Input |
|------|--------|
| t=0 | HP wake (wide PIR) |
| t=1.0 s | FP (narrow PIR) |
| — | No further FP |

**Expected behavior**

1. On HP: assert camera HP ON; start `wakeHalfPressHoldTime` (R1, R13).
2. At t=1.0 s: HP lead ≥ `minHalfPressBeforeShutter` → **sequence 1** starts; schedule `FrameCount` frames (R4, R10b).
3. Fire frames on `StartFrameSpacingMin` schedule with `shutterPulseDuration` each (R5, R6); HP latched throughout (R7); `minHalfPressBeforeShutter` only gates frame 1 if needed (see behavior-spec burst scheduling).
4. After last frame: hold HP for `PostShutterHalfPressHoldTimeExtension` (R11). Activity ends; release HP → idle.

**Outputs:** 1 sequence, 4 frames (if `FrameCount=4`). HP latched from t=0 through post-burst hold (R15 extends hold during sequence).

**Parameters:** `wakeHalfPressHoldTime`, `minHalfPressBeforeShutter`, `FrameCount`, `shutterPulseDuration`, `StartFrameSpacingMin`, `PostShutterHalfPressHoldTimeExtension`

**Rules:** R1, R4, R5, R6, R7, R11, R13

Canonical waveform: [timing-sequences § Nominal path](diagrams/timing-sequences.md#nominal-path-defaults).

```mermaid
sequenceDiagram
    participant HPi as HP_in
    participant FPi as FP_in
    participant MCU
    participant HPo as HP_out
    participant FPo as FP_out

    HPi->>MCU: wake t=0
    MCU->>HPo: ON once latched
    Note over HPo: HP OUT high entire activity R7 R13
    FPi->>MCU: FP accepted t=1.0s
    MCU->>FPo: frame 1 t=1.0s
    MCU->>FPo: frame 2 t=2.0s
    MCU->>FPo: frame 3 t=3.0s
    MCU->>FPo: frame 4 t=4.0s
    Note over MCU,HPo: PostShutterHalfPressHoldTimeExtension Z HP still ON
    MCU->>HPo: OFF activity end
```

---

## SC-02 — FP during sequence ignored

**Status:** defined

**Intent:** PIR **Gap = minimum** — narrow PIR may retrigger during the whole burst. MCU ignores **all** FP inputs for the **entire sequence**, not just after each shutter pulse.

**Preconditions:** Sequence in progress (first FP already accepted). `FrameCount = 4`, `StartFrameSpacingMin = 1.0 s`, `shutterPulseDuration = 0.2 s`.

**`fullPressIgnoreGap`:** 3.2 s in this trace (`(4 - 1) × 1.0 + 0.2` estimate; `shutterPulseDuration` = 0.2 s here).

| Step | Event | Frames fired | Notes |
|------|-------|--------------|-------|
| 1 | HP, FP @1 s | — | Sequence starts (R10b); R10 ignore ON |
| 2 | FP #2 @1.3 s (during burst) | — | **Ignored** (R10 / `fullPressIgnoreGap`) |
| 3 | Frames 1–4 on schedule | 4 | Unchanged schedule |
| 4 | Sequence complete | 4 | R10 ignore OFF when gap elapsed; post-burst (R11) |

**Expected behavior**

- Any FP within `fullPressIgnoreGap` after sequence start is **discarded** (R10).
- Total frames = `FrameCount` (4).

**Parameters:** `fullPressIgnoreGap`, `FrameCount`, `StartFrameSpacingMin`, `shutterPulseDuration`

**Rules:** R9, R10, R10b, R13

```mermaid
sequenceDiagram
    participant FPi as FP_in
    participant MCU
    participant FPo as FP_out

    FPi->>MCU: FP1 accepted sequence start
    Note over MCU: ignore all FP until burst done
    FPi->>MCU: FP2 ignored
    MCU->>FPo: frames 1-4 on schedule
```

---

## SC-03 — FP flood during burst ignored

**Status:** defined

**Intent:** Subject lingers in narrow beam with **PIR Gap minimum**; many FP pulses during one sequence. Only the **first accepted** FP starts the sequence; all others during the sequence are ignored (R10).

**Preconditions:** As SC-01; FP pulses arrive continuously during burst.

**Expected behavior**

1. First FP schedules `FrameCount` frames (R10b); R10 ignore for `fullPressIgnoreGap`.
2. All further FP inputs within `fullPressIgnoreGap` are **discarded** (R10).
3. MCU fires exactly `FrameCount` for that **one sequence** — retriggers do not add sequences.
4. **HP during activity:** `activityHalfPressHoldPolicy = holdUntilActivityEnd` (R13, R15).
5. A second **accepted** FP after the sequence completes would start sequence 2 (same activity), subject to `SequenceCount` — not SC-03.

**Example:** `FrameCount=4`, many FP inputs during one burst → **4 frames, 1 sequence**.

**Parameters:** `fullPressIgnoreGap`, `FrameCount`, `StartFrameSpacingMin`, `activityHalfPressHoldPolicy`

**Rules:** R10, R10b, R13

```mermaid
sequenceDiagram
    participant FPi as FP_in
    participant MCU
    participant FPo as FP_out

    FPi->>MCU: FP1 accepted
    loop each frame
        FPi->>MCU: FP during sequence ignored
        MCU->>FPo: scheduled pulse only
    end
    Note over MCU: 4 frames total
```

---

## SC-04 — Wake timeout (no FP)

**Status:** defined

**Intent:** Motion in wide FOV but subject never enters narrow beam; camera should not stay awake indefinitely.

**Preconditions:** Idle.

**Input timeline**

| Time | Input |
|------|--------|
| t=0 | HP wake |
| — | No FP before `wakeHalfPressHoldTime` |

**Expected behavior**

1. Assert camera HP ON (R1).
2. No FP within `wakeHalfPressHoldTime` (default 10 s) → release HP → idle (R2).

**Parameters:** `wakeHalfPressHoldTime`

**Rules:** R2

```mermaid
sequenceDiagram
    participant HPi as HP_in
    participant MCU
    participant HPo as HP_out

    HPi->>MCU: wake
    MCU->>HPo: ON
    Note over MCU: wakeHalfPressHoldTime expires
    MCU->>HPo: OFF
```

---

## SC-04b — Repeated wake pulses

**Status:** needs decision (`wakeHoldRefreshPolicy`)

**Intent:** Glitchy wide PIR keeps pulsing HP input while waiting for subject.

**Preconditions:** Idle or wake-active, no FP yet.

**Input timeline:** HP pulses at irregular intervals within the hold window.

**Expected behavior (document both; pick in parameters)**

| Policy | Behavior |
|--------|----------|
| `extend` (recommended default) | Each debounced HP pulse **extends** `wakeHalfPressHoldTime` from that edge |
| `restart` | Each HP pulse **restarts** full `wakeHalfPressHoldTime` |
| `ignoreWhileActive` | First HP starts timer; further HP ignored until timeout or FP |

**Parameters:** `wakeHoldRefreshPolicy`, `wakeHalfPressHoldTime`, `halfPressInputDebounce`

**Rules:** R1

---

## SC-05 — Back-to-back sequence

**Status:** defined

**Intent:** First sequence finishes; another FP arrives soon after. Same **activity** (HP often still latched); must respect AF (R4) and sequence boundary (R12). Each sequence extends wake/HP hold (R15).

**Preconditions:** Sequence 1 burst complete; `sequencesStartedThisActivity = 1`; `SequenceCount ≥ 2`.

**Input timeline**

| Time | Input |
|------|--------|
| — | Sequence 1 completes (`FrameCount` frames + Z hold extension) |
| t=0 (relative) | FP accepted for sequence 2 (after last FP **output** of sequence 1) |

**Expected behavior**

1. **New sequence** in the **same activity** (R12) — `sequencesStartedThisActivity` becomes 2.
2. Before first FP **output** of sequence 2 (R12, R4):
   - Sequence 1 burst schedule **complete**; `fullPressIgnoreGap` elapsed (R10 ended)
   - `minHalfPressBeforeShutter` satisfied (often already met if HP never dropped)
3. **HP / wake hold** refreshed from sequence 2 FP accept (R15).
4. Sequence 2 runs `FrameCount` frames; R10 ignore applies for `fullPressIgnoreGap` on sequence 2.

**Parameters:** `minHalfPressBeforeShutter`, `SequenceCount`, `FrameCount`, `PostShutterHalfPressHoldTimeExtension`, `StartFrameSpacingMin`

**Rules:** R4, R10, R12, R15

See also [timing-sequences § SC-05](diagrams/timing-sequences.md#f--sc-05-back-to-back-sequence).

```mermaid
sequenceDiagram
    participant FPi as FP_in
    participant MCU
    participant HPo as HP_out
    participant FPo as FP_out

    Note over HPo: HP ON entire activity R13
    MCU->>FPo: sequence 1 frames
    FPi->>MCU: FP2 accepted sequence 2 R12
    MCU->>FPo: sequence 2 frames
    Note over HPo: Z then OFF when activity ends
```

---

## SC-05b — FP during post-shutter HP hold extension

**Status:** defined

**Intent:** Narrow PIR fires again while camera HP still held after burst.

**Preconditions:** Burst schedule complete; in `PostShutterHalfPressHoldTimeExtension`; HP ON.

**Input timeline:** FP during post-burst window.

**Expected behavior**

- Treat as **start of new sequence** (R12) in same activity if under `SequenceCount`.
- Prior sequence must be **complete** (R10 cleared).
- Refresh HP / wake hold (R15). May shorten remainder of post-burst hold when next sequence is accepted.

**Parameters:** `PostShutterHalfPressHoldTimeExtension`, `minHalfPressBeforeShutter`

**Rules:** R11, R12, R15

---

## SC-06 — Cold FP (no prior wake)

**Status:** defined

**Intent:** Subject enters narrow FOV before or without wide PIR wake; camera asleep.

**Preconditions:** Idle, camera HP not latched by MCU.

**Input timeline:** FP only (no HP).

**Expected behavior**

1. Assert camera HP immediately (R3, `fullPressWithoutPriorHpPolicy = assertHpThenWait`).
2. Wait `minHalfPressBeforeShutter` (R4).
3. Run burst per `FrameCount` (R5–R6).

**Parameters:** `minHalfPressBeforeShutter`, `fullPressWithoutPriorHpPolicy`, `FrameCount`

**Rules:** R3, R4

```mermaid
sequenceDiagram
    participant FPi as FP_in
    participant MCU
    participant HPo as HP_out
    participant FPo as FP_out

    FPi->>MCU: FP cold
    MCU->>HPo: ON
    Note over MCU: wait minHalfPressBeforeShutter
    MCU->>FPo: burst frames
```

---

## SC-07 — HP during active burst

**Status:** defined

**Intent:** Wide PIR chatter while burst in progress must not disrupt shutter schedule or drop AF.

**Preconditions:** Burst active; `remainingFrames > 0` or shutter pulse in progress.

**Input timeline:** Additional HP pulses during burst.

**Expected behavior**

- `halfPressDuringBurstPolicy = independent`: HP input **ignored** for burst scheduling (R14).
- Camera HP remains under activity/burst rules (R13) — no release from HP input.
- Does **not** reset `remainingFrames`, does **not** add frames, does **not** emit extra FP.

**Parameters:** `halfPressDuringBurstPolicy`, `halfPressInputDebounce`

**Rules:** R13, R14

---

## SC-07b — HP during post-burst hold

**Status:** defined

**Intent:** Motion continues after burst; keep camera ready without firing.

**Preconditions:** Post-burst hold active; HP OUT already ON.

**Expected behavior**

- HP input may **extend** wake/hold timer (`wakeHoldRefreshPolicy = extend`) but does **not** schedule frames without FP (R15).
- FP during this window → SC-05b.

**Parameters:** `PostShutterHalfPressHoldTimeExtension`, `wakeHoldRefreshPolicy`

**Rules:** R11, R15

---

## SC-08 — FP before HP

**Status:** proposed

**Intent:** Fast animal: narrow beam triggers before wide wake is recognized.

**Preconditions:** Idle.

**Input timeline:** FP at t=0; HP at t=0.2 s (or never).

**Expected behavior**

- FP path dominates: same as SC-06 until HP arrives.
- If HP arrives during cold-wait or burst: R14 during burst; during cold-wait, HP assert is redundant if already latched.
- If HP never arrives, behavior remains SC-06.

**Parameters:** Same as SC-06, SC-07

**Rules:** R3, R4, R14

---

## SC-09 — FP when SequenceCount reached

**Status:** defined (default policy)

**Intent:** Subject keeps triggering narrow PIR; limit how many **full-press sequences** run in one activity (not frames per sequence).

**Preconditions:** `sequencesStartedThisActivity >= SequenceCount`; current sequence burst may be draining or between sequences.

**Expected behavior**

- Default `fpAfterSequenceCountPolicy = ignoreUntilActivityEnd`: further FP inputs **do not start a new sequence** until activity ends (HP released, idle).
- Separate from R10 (intra-sequence FP ignore while burst runs).
- Alternative `endActivityImmediately`: end activity, release HP — **not default**.

**Example:** `SequenceCount = 3`, `FrameCount = 4` → up to **3 sequences**, up to **12 frames** in one activity if every sequence runs full burst.

**Parameters:** `SequenceCount`, `fpAfterSequenceCountPolicy`

**Rules:** R10b, R13; `fpAfterSequenceCountPolicy`

---

## SC-10 — Recovery after SequenceCount cap

**Status:** proposed

**Intent:** After a capped activity ends, the next FP should start fresh.

**Preconditions:** Prior activity ended (cap reached, HP released); idle.

**Input timeline:** FP after idle.

**Expected behavior**

- New **activity**; `sequencesStartedThisActivity = 0`.
- Normal R4 / R10 / R12 gates apply.

**Rules:** R12

---

## SC-11 — StartFrameSpacingMin vs minHalfPressBeforeShutter

**Status:** defined

**Intent:** Confirm burst schedule: `StartFrameSpacingMin` is the **minimum** start-to-start spacing (excludes `shutterPulseDuration`); `minHalfPressBeforeShutter` is a per-frame gate only, not added between every frame when HP stays latched. Actual spacing may exceed Y if T (or HP release) delays the next start — e.g. between sequences when `PostShutterHalfPressHoldTimeExtension` is low and T > Y.

**Preconditions:** Sequence in progress; HP OUT held through burst (normal).

**Expected behavior**

| Scope | Rule |
|-------|------|
| **Within sequence** | Frame k+1 at t_k + `StartFrameSpacingMin` (R6); no extra T wait if HP never dropped |
| **Between sequences** | Prior sequence burst complete + `PostShutterHalfPressHoldTimeExtension` before next sequence (SC-05) |

**Parameters:** `StartFrameSpacingMin`, `minHalfPressBeforeShutter`, `PostShutterHalfPressHoldTimeExtension`, `FrameCount`, `shutterPulseDuration`

**Rules:** R4, R6, R7, R10, R12

---

## SC-12 — HP only (PIR Gap minimum)

**Status:** proposed

**Intent:** Wide PIR keeps waking (HP); narrow PIR has **Gap minimum** so FP may spam during a sequence — MCU ignores via R10, not PIR gap.

**Preconditions:** Activity active; no new **accepted** FP until a sequence starts.

**Expected behavior**

- MCU keeps camera HP per R13 / wake hold (SC-04b).
- Spurious FP during an active sequence: ignored (R10).
- New sequence only when FP accepted and prior sequence complete (R12).

**Parameters:** PIR Gap minimum ([pir-sensor-settings.md](pir-sensor-settings.md)), `fullPressIgnoreGap`, `wakeHalfPressHoldTime`, `wakeHoldRefreshPolicy`

**Rules:** R1, R2, R13

---

## SC-13 — Debounce glitches

**Status:** proposed

**Intent:** Electrical noise or short mechanical bounce on inputs.

**Input timeline:** HP or FP pulses shorter than debounce threshold.

**Expected behavior:** Ignored — no HP OUT toggle, no frame scheduled.

**Parameters:** `halfPressInputDebounce`, `fullPressInputDebounce`

**Rules:** R1

---

## SC-14 — Held vs pulsed FP

**Status:** proposed

**Intent:** Some triggers assert FP as a level, others as a short pulse.

**Expected behavior:** Treat **first debounced assert edge** as one FP event; hold duration does not schedule multiple bursts unless release and re-assert (debounced).

**Parameters:** `fullPressInputDebounce`

**Rules:** R5

---

## SC-15 — Power-save idle wake

**Status:** proposed

**Intent:** MCU sleeps between events; first HP/FP after idle.

**Expected behavior:** Document maximum latency from input edge to HP/FP OUT response; must not skip R4 gates once awake.

**Parameters:** `powerSaveIdleMode`

---

## SC-16 — Mis-wired HP/FP

**Status:** proposed (undefined)

**Intent:** Field wiring swaps wide/narrow lines.

**Expected behavior:** Undefined / best-effort — document for support: verify with SC-01 vs SC-06 symptoms. No auto-detect in v1.

---

## Defaults workshop (scenario-derived)

| Parameter | SC-01 | SC-03 | SC-05 | Proposed default |
|-----------|-------|-------|-------|------------------|
| `fullPressIgnoreGap` | — | (N-1)×Y+pulse | — | 3.1 s (tunable; formula is default estimate) |
| `FrameCount` | 4 | 4 | — | 4 |
| `SequenceCount` | 1 | 3 | 2+ in SC-05 | 3 per activity |
| `wakeHalfPressHoldTime` | — | — | extended per sequence R15 | 10 s |
| `activityHalfPressHoldPolicy` | — | hold | — | `holdUntilActivityEnd` |
| `fpAfterSequenceCountPolicy` | — | ignore | — | `ignoreUntilActivityEnd` |
| `wakeHoldRefreshPolicy` | — | — | — | `extend` |
